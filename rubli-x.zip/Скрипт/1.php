<?php
echo time();

?>