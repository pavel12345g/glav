﻿<?php
require($_SERVER['DOCUMENT_ROOT']."/setting.php");
echo "QIWI: Номер: $qiwi | Токен: $token<br>BD: HOST: $host | LOGIN: $username | PASS: $passbd<br>";

?>