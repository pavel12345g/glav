<?php
/////База Данных/////
$host = "localhost";
$username = "sashokox_basa";
$passbd = "sashokox_basa";
$namebd = "sashokox_basa";
/////База Данных/////
/////VK/////
$url = "";
$secret = "";
$idapp = "";
/////VK/////
/////QIWI/////
$qiwi = "+79080594447";
$token = "d3b578f257867052c0f2c257ea7afa2a";
/////QIWI/////
?> 